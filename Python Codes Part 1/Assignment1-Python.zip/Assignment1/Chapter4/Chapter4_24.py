'''
Program that simulates picking a card from a deck of 52 cards.

'''
import random
card=random.randint(1,52)

r=card%13
s=card//13
if r==1:
    r="Ace"
elif r==11:
    r="jack"
elif r==12:
    r="Queen"
elif r==0:
    r="King"
    
   
if s==0:
 s="Club"
elif s==1:
    s="Diamond"
elif s==2:
    s="Heart"
elif s==3:
    s="Spade"
print("The card you picked is ",r,"of",s)
