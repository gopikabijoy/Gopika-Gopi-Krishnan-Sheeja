'''
Program to check whether user entered sum of digits is correct or not

'''
import random
x = random.randint(0,10)
y = random.randint(0,10)
sum1=x+y
sum2=eval(input("enter the sum of " +str(x) + " and " +str(y) +" "))
if sum1==sum2:
 print("Correct Answer")
else:
 print("Wrong Answer")