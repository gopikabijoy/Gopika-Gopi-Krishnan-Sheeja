'''
Program to find whether the user won a lottery

'''

import random
x=random.randint(100,999)
user=eval(input("Enter Your 3-digit Lottery Number: "))


x1=x%10           #to extract the last digit
x2=(x%100)//10    #to extract the second digit
x3=x//100         #to extract the first digit

user1=user%10
user2=(user%100)//10
user3=user//100


if x==user:
 print("You won 10,000$ cash")
elif (((x1==user1) and (x2==user3) and (x3==user2)) or ((x2==user2) and (x1==user3) and (x3==user1)) or ((x3==user3) and (x1==user2) and (x2==user1))):
 print("you won 3000$ cash")
elif((x1==user1) or (x2==user3) or (x3==user2) or (x2==user1) or (x2==user3) or (x3==user1) or (x3==user2)):
 print("You won 1000$")
else:
 print("Sorry better luck next time")