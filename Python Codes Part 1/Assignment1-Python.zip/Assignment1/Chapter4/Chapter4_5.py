'''
Prgram to find the day corresponding to a number
'''

day=eval(input("Enter today's day: "))
elapse=eval(input("Enter the number of days elapsed since today: "))


D=(day+elapse)%7        #To find the corresponding day in single digit
    
if D==0:
    D="Sunday"
elif D==1:
    D="Monday"
elif D==2:
    D="Tuesday"
elif D==3:
    D="Wednesday"
elif D==4:
    D="Thursday"
elif D==5:
    D="Friday"
elif D==6:
    D="Saturday"
    
if day==0:
    d="Sunday"
elif day==1:
    d="Monday"
elif day==2:
    d="Tuesday"
elif day==3:
    d="Wednesday"
elif day==4:
    d="Thursday"
elif day==5:
    d="Friday"
elif day==6:
    d="Saturday"
    
print("Today is "+str(d)+" and the future day is "+str(D))
        
    
    

