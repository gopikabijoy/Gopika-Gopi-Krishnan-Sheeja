'''
Program for rock,paper,scissor game

'''

import random
x = random.randint(-1,2)

y=eval(input("scissor (0), rock (1), paper (2): Please enter your Choice: "))
if (x==0 and y==1):
    print("The computer is scissor.You are rock.You won")
elif(x==0 and y==2):
    print("The computer is scissor.You are paper.you lost")
elif(x==1 and y==0):
    print("The computer is rock.You are scissor.You lost")
elif(x==1 and y==2):
    print("The computer is rock.You are paper.You won")
elif(x==2 and y==0):
    print("The computer is paper.You are Scissor.You won")
elif(x==2 and y==1):
    print("The computer is paper.You are rock.you lost")
else:
    print("Draw")