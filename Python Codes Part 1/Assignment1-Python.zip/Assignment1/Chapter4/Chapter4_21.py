'''
Program to calculate the day of the week using Zeller's Congruence

'''

Y=eval(input("Enter year: "))
m=eval(input("Enter month: 1-12: "))
q=eval(input("Enter the day of the month: 1-31: "))
if m== 1:
    m = m + 12
    Y=Y-1
elif m == 2:
    m = m + 12
    Y=Y-1

k=Y%100               #Year of century
j=Y//100              #Century 

h= (q+((26*(m+1))//(10))+k+((k)//(4))+((j)//(4))+(5*j))%7

if h==0:
    print("The day of the week is Saturday")
elif h==1:
    print("The day of the week is Sunday")
elif h==2:
    print("The day of the week is Monday")
elif h==3:
    print("The day of the week is Tuesday")
elif h==4:
    print("The day of the week is Wednesday")
elif h==5:
    print("The day of the week is Thursday")
elif h==6:
    print("The day of the week is Friday")
  
       
