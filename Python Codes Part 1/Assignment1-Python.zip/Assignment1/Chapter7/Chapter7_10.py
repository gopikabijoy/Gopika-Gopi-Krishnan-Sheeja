'''
Design a class named Time.

'''
import time
class Time:
    def __init__(self):
       
        currentTime = time.time() # Get current time
        totalSeconds = int(currentTime)  # Obtain the total seconds since midnight, Jan 1, 1970
        self.__s = totalSeconds % 60
        totalMinutes = totalSeconds // 60
        self.__m = totalMinutes % 60
        totalHours = totalMinutes // 60
        self.__h = totalHours % 24
        
    def gethour(self):
        return self.__h
    def getminute(self):
        return self.__m
    def getsecond(self):
        return self.__s
    def setTime(self,elapseTime):
        self.__s=elapseTime%60
        self.__m=(elapseTime//60)%60
        self.__h=(elapseTime//3600)%24
        
def main():
    t=Time()
    print("Current time is : ",t.gethour(),":",t.getminute(),":",t.getsecond())
    elapse=eval(input("Enter the elapsed time :  "))
    t.setTime(elapse)
    print("The hour:minute:second for the elapsed time is  ",t.gethour(),":",t.getminute(),":",t.getsecond())
        
main()