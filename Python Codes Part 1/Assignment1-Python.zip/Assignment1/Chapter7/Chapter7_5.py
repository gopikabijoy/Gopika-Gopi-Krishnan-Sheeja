'''
Design a class named RegularPolygon with details
'''
from math import tan,pi
class RegularPolygon:
    
    
    def __init__(self,n=3,side=1,x=0,y=0):
        self.__sidenumber=n
        self.__sidelength=side
        self.__X=x
        self.__Y=y
    def getsidenumber(self):
        return self.s__idenumber
    def getlength(self):
        return self.__sidelength
    def getx(self):
        return self.__X
    def gety(self):
        return self.__Y
    
    def getPerimeter(self):
        return self.__sidenumber*self.__sidelength
    
    def getArea(self):
        n=self.__sidenumber
        s=self.__sidelength
        area=n*s**2/(4*tan(pi/n))
        return area
    
    def setsidenumber(self,sidenumber):
        self.n=sidenumber
    def setlength(self,length):
        self.side=length
    def setx(self,xcoordinate):
        self.x=xcoordinate
    def sety(self,ycoordinate):
        self.y=ycoordinate
def main():
    
    R1=RegularPolygon()  
    R2=RegularPolygon(6, 4)
    R3=RegularPolygon(10, 4, 5.6, 7.8)
    print("The perimeter of polygon 1 is :",R1.getPerimeter())
    print("The perimeter of polygon 2 is :",R2.getPerimeter())
    print("The perimeter of polygon 3 is :",R3.getPerimeter())
    print("The area of polygon 1 is :",R1.getArea())
    print("The area of polygon 2 is :",R2.getArea())
    print("The area of polygon 3 is :",R3.getArea())
    
main()