'''
Design a class named Account with details

'''
class Account:
    def __init__(self,id=0,initialbalance=100,AnnualInterestRate=0):
        self.__balance=initialbalance
        self.__id=id
        self.__annualInterestRate=AnnualInterestRate

    def getbalance(self):
        return self.__balance
    
    def getid(self):
       return self.__id
    
    def getannualInterestRate(self):
        return self.__annualInterestRate
    
    def getMonthlyInterestRate(self):
        return self.__annualInterestRate/12
    
    def getMonthlyInterest(self):
        return (self.__balance*(self.getMonthlyInterestRate())/100)
    def setid(self,id):
        self.__id=id
    def setbalance(self,balance):
        self.__balance=balance
    def setAnnualInterestRate(self,rate):  
        self.__annualInterestRate=rate 
         
    def withdraw(self,amt):
        
       self.__balance-=amt
       return self.__balance

    def deposit(self,amt):
   
        self.__balance+=amt
        return self.__balance


def main():
    A=Account(1122,20000,4.5)    
    
    print("ID is : ", A.getid())
    print("Balance after withdrawing 3000$ is ",A.withdraw(2500),"$") 
    print("Balance after depositing 2500$ is ",A.deposit(3000),"$")
    print("Balance Amount is : ",A.getbalance(),"$")
    print("Monthly Interest Rate is : " ,A.getMonthlyInterestRate(),"%")
    print("Monthly Interest is : ", A.getMonthlyInterest(),"$")
    
main()