'''
Line intersection using class
'''
from math import sqrt
from LinearEquation import LinearEquation

def getpoints():
    x1,x2,x3,x4=eval(input("Enter the end points of the first line "))
    x5,x6,x7,x8=eval(input("Enter the end points of the second line "))
    return x1,x2,x3,x4,x5,x6,x7,x8
def linearcoefficients(x0,y0,x1,y1):
    if x1!=x0:
        m=(y1-y0)/(x1-x0)
        return m,-1,m*x0-y0
    else:
        return 1,0,x0
def distance(x0,y0,x1,y1):
    return sqrt((x1-x0)**2+(y1-y0)**2)
def isbetween(ax,ay,bx,by,cx,cy):
    epsilon=1e-6
    return abs(distance(ax,ay,cx,cy)+distance(bx,by,cx,cy)-distance(ax,ay,bx,by))<epsilon

def main():
    
    x1,y1,x2,y2,x3,y3,x4,y4=getpoints()
    a,b,e=linearcoefficients(x1,y1,x2,y2)
    c,d,f=linearcoefficients(x3,y3,x4,y4)
    eqnt=LinearEquation(a,b,c,d,e,f)
    
    if not eqnt.isSolvable():
        print("There is no point of intersection")
    else:
        i1,i2=eqnt.getX(),eqnt.getY()
        if isbetween(x1,y1,x2,y2,i1,i2) and isbetween(x3,y3,x4,y4,i1,i2):
            print("The intersecting point is (",i1,i2,")")
        else:
            print("there is no intersection point")
            
main()
    
    