class LinearEquation:
    def __init__(self,a,b,c,d,e,f):
        
        self.__A=a
        self.__B=b
        self.__C=c
        self.__D=d
        self.__E=e
        self.__F=f
        
    def geta(self):
        return self.__A
    def getb(self):
        return self.__B
    def getc(self):
        return self.__C
    def getd(self):
        return self.__D
    def gete(self):
        return self.__E
    def getf(self):
        return self.__F
   
        
    def isSolvable(self):
        return ((self.__A*self.__D)-(self.__B*self.__C))!=0
        
    def getX(self):
        return ((self.__E*self.__D)-(self.__B*self.__F))/((self.__A*self.__D)-(self.__B*self.__C))
    def getY(self):
        return ((self.__A*self.__F)-(self.__E*self.__C))/((self.__A*self.__D)-(self.__B*self.__C))