'''
Program that displays a clock to show the time 9:15:00

'''
import turtle
turtle.penup()
turtle.goto(0,-100)
turtle.pendown()
turtle.circle(200)
turtle.penup()
turtle.goto(-10,100)
turtle.pendown()
turtle.backward(130)
turtle.forward(280)
turtle.penup()
turtle.goto(190,100)
turtle.write(3)
turtle.penup()
turtle.goto(0,280)
turtle.write(12)
turtle.penup()
turtle.goto(0,-90)
turtle.write(6)
turtle.goto(-190,100)
turtle.write(9)
turtle.penup()
turtle.goto(-20,-120)
turtle.write("9:15:00")    #to display the time

turtle.hideturtle()
turtle.done()