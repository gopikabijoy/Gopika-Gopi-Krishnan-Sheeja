'''
Program to find the population growth
'''

P=312032486      #current population
B=(24*3600*365)//7   #Rate of birth per day
D=(24*3600*365)//13    #Rate of death per day
I=(24*3600*365)//45    #Rate of immigrant per day

Y1=P+((B)-(D)+(I))   # population calculation 
Y2=Y1+((B)-(D)+(I))
Y3=Y2+((B)-(D)+(I))
Y4=Y3+((B)-(D)+(I))
Y5=Y4+((B)-(D)+(I))

print("Population by the end of first year is",int((Y1*100)/100.0))
print("Population by the end of second year is",int((Y2*100)/100.0))
print("Population by the end of third year is",int((Y3*100)/100.0))
print("Population by the end of fourth year is",int((Y4*100)/100.0))
print("Population by the end of fifth year is",int((Y5*100)/100.0))