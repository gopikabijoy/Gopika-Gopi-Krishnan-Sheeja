'''
Program to draw a star using turtle module

'''
import turtle

turtle.forward(150)
turtle.right(144)
turtle.forward(150)
turtle.right(144)
turtle.forward(150)
turtle.right(144)
turtle.forward(150)
turtle.right(144)
turtle.forward(150)
turtle.right(144)
turtle.done()