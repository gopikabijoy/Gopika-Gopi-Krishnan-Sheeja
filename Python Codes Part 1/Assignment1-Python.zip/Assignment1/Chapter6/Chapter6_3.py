'''
# Program to check if a number is palindrome or not using functions

'''

# Return the reversal of an integer, e.g. reverse(456) returns
# 654
def reverse(number):
    Rev = 0
    while(number>0):
        Reminder=number%10 
        Rev=Rev*10+Reminder
        number=number//10
    return(Rev)
    
# Return true if number is a palindrome
def isPalindrome(number):
    if ((reverse(number))==number):
        return("true")
    else:
        return("False")
    
def main(): 
    n=eval(input("Please enter a number: ")) 
    r=reverse                       # to store the reversed number
    b=isPalindrome(n)               # to store the return value of isPalindrome() function
    if b=="true":
        print("The number is a palindrome")
    else:
        print("The number is not a palindrome")
        
main()                                   #   calling the main function
