'''
Program to sort numbers in the ascending order using function

'''
def displaySortedNumbers(num1, num2, num3):          # function to sort numbers in ascending order 
    max=0
    mid=0
    if (num1>num2) and (num1>num3):
        max=num1
        if num2>num3:
            min=num3
            mid=num2
        else:
            min=num2
            mid=num3
    if (num2>num1) and (num2>num3):
        max=num2
        if num1>num3:
            min=num3
            mid=num1
        else:
            min=num1 
            mid=num3  
    if (num3>num1) and (num3>num2):
        max=num3
        if num1>num2:
            min=num2
            mid=num1
        else:
            min=num1
            mid=num2
    print("The sorted numbers are: ",min,mid,max)

def main():
    a,b,c=eval(input("Enter three numbers: "))
    displaySortedNumbers(a,b,c)

main()
