'''
Hans Luhn's algorithm for validating credit card numbers implemented using function

'''
def sumOfDoubleEvenPlace(n):
    l2= 0
    sum= 0
    s= 0
    while(n> 0):
        l2= n%100 #Getting last two digits of credit card number
        
        even= l2//10 #getting the even position from last two digits
        
        s= even*2 #doubling the even digit by multiplying with 2
        
        sum+= getDigit(s)
                   
        n=n//100 # removing last 2 digits of the credit card number
        
    return sum
                      
    
# Return this number if it is a single digit, otherwise, return
# the sum of the two digits
 
def getDigit(number):
    if(number < 10):
        return number
    else: 
        number = (number//10 + number % 10)
        return number
    
    
    
# Return sum of odd place digits in number
def sumOfOddPlace(n):
    l2= 0
    sum= 0
    while(n> 0):
        l2=n%100 #Getting last two digits of credit card number
        
        odd=n%10 #getting the even position from last two digits
        
        sum+= odd
                   
        n= n//100 # removing last 2 digits of the credit card number
        
    return sum
    
# Return true if the digit d is a prefix for number
def prefixMatched(n, d):
    return getPrefix(n, getSize(d)) == d


# Return the number of digits in d
def getSize(n):
    count = 0
    while (n> 0):
        n= n // 10
        count += 1
    return count 
# Return the first k number of digits from number. If the
# number of digits in number is less than k, return number.
def getPrefix(n, k):
    if(getSize(n) < k):
        return n
    return n// 10 ** (getSize(n) - k)
       
def isValid(n):
    if not ((13 <= getSize(n) <= 16) and prefixMatched(n, 4) or prefixMatched(n, 5) 
            or prefixMatched(n, 37) or prefixMatched(n, 6)):
        return False
    
    total1 = sumOfDoubleEvenPlace(n)
    total2 = sumOfOddPlace(n)
    
    return (total1 + total2) % 10 == 0
  
def main():
    num=eval(input("Please enter your credit card number: "))
    if isValid(num):
        print("Valid Credit Card")
    else:
        print("Invalid Credit Card")
        
    
main()   



































































