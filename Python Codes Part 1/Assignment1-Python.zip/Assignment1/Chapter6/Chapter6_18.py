'''
Program to display an n*n matrix using function

'''

def printMatrix(n):
    import random
    for i in range(1,n+1):
        for j in range(1,n+1):
            a=random.randint(0,1)
            print(a,end=' ')          #displays 3 elements in a row
            
        print()                 # prompts cursor to jump to the next row
            
        
def main():
    number=eval(input("Enter the order(n) of matrix: "))    
    printMatrix(number)
main()