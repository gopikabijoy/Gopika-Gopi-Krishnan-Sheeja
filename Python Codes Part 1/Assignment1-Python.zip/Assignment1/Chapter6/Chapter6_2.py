'''
Program to determine the sum of digits using functions and while loop

'''
def sumDigits(n):     #Function to determine the sum of digits using while loop
    Sum=0
    while(n>0):
        rem=n%10
        Sum+=rem
        n=n//10
    return(Sum)      
         
def main():   # main function definition
    number=eval(input("Please enter a number : "))
    Sum=sumDigits(number)
    print("The sum of digits of ",number,"is ",Sum)
    
main()      # calling main function
                       