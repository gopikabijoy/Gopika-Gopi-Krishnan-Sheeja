'''
program that displays a rectangle centered at with width
and height 100 and a circle centered at (50, 0) with radius 50. Fill 10 random
points inside the rectangle and 10 inside the circle

'''

# Draw a circle centered at (x, y) with the specified radius

def drawCircle(x,y,radius):  
    import turtle
    import random
    
    turtle.penup() # Pull the pen up
    turtle.goto(x, y - radius)
    turtle.pendown() # Pull the pen down
    turtle.circle(radius)
    
    for i in range(0,10):
        a=random.randint(10,70)
        b=random.randint(0,25)
        turtle.penup()
        turtle.goto(a,b)
        turtle.pendown()
        turtle.dot()

# Draw a rectangle at (x, y) with the specified width and height

def drawRectangle(x,y,width,height):
    import turtle
    import random
    
    turtle.penup() # Pull the pen up
    turtle.goto(x + width / 2, y + height / 2)
    turtle.pendown() # Pull the pen down
    turtle.right(90)
    turtle.forward(height)
    turtle.right(90)
    turtle.forward(width)
    turtle.right(90)
    turtle.forward(height)
    turtle.right(90)
    turtle.forward(width)
    
    for i in range(0,10):
        a=random.randint(-117,-40)
        b=random.randint(1,30)
        turtle.penup()
        turtle.goto(a,b)
        turtle.pendown()
        turtle.dot()
    
def main():
    
    drawCircle(50,0,50)
    drawRectangle(-75,0,100,100)
    
    
main()
        
