'''
Program to print the number of prime numbers less than 10,000 
'''
def isPrime():
    flag=0
    for i in range(2,10000):
        count=0
        for j in range(1,i+1):
            if(i%j==0):
                count+=1
                      
        if(count==2):
            flag+=1
    print(flag)
def main():
    
    print("number of prime numbers less than 10,000 is: ")
    isPrime()
    
main()