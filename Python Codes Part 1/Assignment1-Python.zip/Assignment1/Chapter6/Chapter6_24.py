'''
Program to print the first 100 palindromic prime numbers

'''
def isPrime():
    c=0
    flag=0
    for i in range(2,10000):      # to check if the number is prime or not
        count=0
        for j in range(1,i+1):
            if(i%j==0):
                count+=1
            
            
           
        if(count==2):
            Rev = 0
            temp=i
            while(temp>0):         # to check if the number is palindrome
                Reminder=temp%10
                Rev=Rev*10+Reminder
                temp=temp//10
                
            if Rev==i:
                print(i,end=' ')
                c+=1
                
                if c==10:    # to print the numbers in next line after reaching maximum limit of 10
                    print("\n")
                    c=0
               
def main():
    c=print("The first 100 Palindromic Prime numbers are: ")
    isPrime()
    
main()    
