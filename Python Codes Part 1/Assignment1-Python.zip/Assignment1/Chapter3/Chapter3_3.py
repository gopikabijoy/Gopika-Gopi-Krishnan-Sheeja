'''
Program to find the GPS locations for Atlanta, Georgia;
Orlando, Florida; Savannah, Georgia; and Charlotte, North Carolina and compute the estimated area enclosed by these four cities

d = radius * arccos(sin(x1) * sin(x2) + cos(x1) * cos(x2) * cos(y1 - y2))
'''

from math import radians,acos,sin,cos,sqrt


x1, y1=radians(33.76), radians(-84.42)    #Atlanta
x2, y2=radians(28.53), radians(-81.38)      #orlando
x3, y3=radians(32.08), radians(-81.09)  #savannah
x4, y4=radians(35.22), radians(-80.84)      #charolette

radius=6371.01


#distance between Atlanta and orlando
d1= abs(radius *acos((sin(x1) * sin(x2) + cos(x1) * cos(x2) * cos(y1 - y2))))
#distance between orlando and savannah
d2= abs(radius *acos((sin(x2) * sin(x3) + cos(x2) * cos(x3) *cos(y2 - y3))))
#distance between savannah and charlotte
d3= abs(radius *acos((sin(x3) * sin(x4) + cos(x3) * cos(x4) * cos(y3 - y4))))
#distance between  charlotte and atlanta
d4= abs(radius *acos((sin(x4) * sin(x1) + cos(x4) * cos(x1) * cos(y4 - y1))))
#distance between atlanta and savannah
d5= abs(radius *acos((sin(x1) * sin(x3) + cos(x1) * cos(x3) * cos(y1 - y3))))


s1  = (d4 + d3 + d5)/2
area1 = sqrt(s1*(s1-d4)*(s1-d3)*(s1-d5))

#area of triangle two: atl-orl-sav
s2=(d1 + d2 + d5)/2
area2=sqrt(s2*(s2-d1)*(s2-d2)*(s2-d5))
totalarea=area1+area2

print("Area enclosed by the cities is : ",totalarea,"KM 2")