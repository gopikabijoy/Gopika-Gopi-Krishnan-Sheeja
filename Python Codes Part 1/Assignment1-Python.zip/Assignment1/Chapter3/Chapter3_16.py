'''
program that draws a triangle, square, pentagon,hexagon, and octagon using turtle

'''

# for drawing a triangle

import turtle
turtle.penup()
turtle.goto(-350,0)
turtle.setheading(60)
turtle.pendown()
turtle.forward(100)
turtle.setheading(-60)
turtle.forward(100)
turtle.setheading(180)
turtle.forward(100)

# for drawing a square

turtle.penup()
turtle.right(180)
turtle.forward(120)
turtle.pendown()
turtle.forward(90)
turtle.left(90)
turtle.forward(90)
turtle.left(90)
turtle.forward(90)
turtle.left(90)
turtle.forward(90)
turtle.left(90)
turtle.forward(90)

 # for drawing a pentagon
turtle.penup()               
turtle.forward(70)
turtle.pendown()
turtle.forward(70)
turtle.left(72)
turtle.forward(70)
turtle.left(72)
turtle.forward(70)
turtle.left(72)
turtle.forward(70)
turtle.left(72)
turtle.forward(70)
turtle.left(72)
turtle.forward(70)

# for drawing a hexagon

turtle.penup()
turtle.forward(80)
turtle.pendown()
turtle.forward(60)
turtle.left(60)
turtle.forward(60)
turtle.left(60)
turtle.forward(60)
turtle.left(60)
turtle.forward(60)
turtle.left(60)
turtle.forward(60)
turtle.left(60)
turtle.forward(60)
turtle.left(60)
turtle.forward(60)


# for drawing an octagon

turtle.penup()
turtle.forward(100)
turtle.pendown()
turtle.forward(40)
turtle.left(45)
turtle.forward(40)
turtle.left(45)
turtle.forward(40)
turtle.left(45)
turtle.forward(40)
turtle.left(45)
turtle.forward(40)
turtle.left(45)
turtle.forward(40)
turtle.left(45)
turtle.forward(40)
turtle.left(45)
turtle.forward(40)
turtle.left(45)
turtle.forward(40)

turtle.done()
