'''
program to find the reverse of a number

'''

n=eval(input("Enter a four digit integer: "))

D1=n%10
n1=n//10
D2=n1%10
n2=n1//10
D3=n2%10
n3=n2//10

       
print("The reversed number is " ,'%d%d%d%d' % (D1,D2,D3,n3))