name=input("Enter employee's name: ")
Hours=eval(input("Enter number of hours worked in a week: "))
Payrate=eval(input("Enter hourly pay rate: "))
federaltax=eval(input("Enter federal tax withholding rate: "))
statetax=eval(input("Enter state tax withholding rate: "))

print("Employee name: ",name)
print("Hours worked: ",int(Hours*10)/10)
print("Pay Rate: $"+str(Payrate))
print("Gross Pay: $"+str(Payrate*Hours))
print("Deductions:")

Deduction= (federaltax*Payrate*Hours)+(statetax*Payrate*Hours)
Netpay=(Payrate*Hours)-Deduction

print("     Federal Withholding(",federaltax,"%): ", format((federaltax*Payrate*Hours),"0.1f"))
print("     State Withholding(",statetax,"%): ", format((statetax*Payrate*Hours),"0.2f"))
print("Total Deduction: $"+str(format(Deduction,"0.2f")))
print("Netpay: $"+str(format(Netpay,"0.2f")))