'''
a program that prompts the user to enter two points
and draw a line to connect the points and displays the coordinates of the points

'''
import turtle
x1,y1,x2,y2=eval(input("Enter two pairs of coordinate points : "))
turtle.penup()
turtle.goto(x1,y1)
turtle.write(str(x1)+","+str(y1))


turtle.pendown()
turtle.goto(x2,y2)
turtle.write(str(x2)+","+str(y2))
turtle.penup()

turtle.write(x2,y2)
turtle.hideturtle()
turtle.done()