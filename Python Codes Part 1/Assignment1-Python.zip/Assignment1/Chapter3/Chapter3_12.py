'''
Program to draw a star with user input being length using turtle module

'''
import turtle


l=eval(input("Enter the length of the star : "))
turtle.penup()
turtle.goto(-50,10)
turtle.pendown()
turtle.forward(l)
turtle.right(144)
turtle.forward(l)
turtle.right(144)
turtle.forward(l)
turtle.right(144)
turtle.forward(l)
turtle.right(144)
turtle.forward(l)
turtle.right(144)

turtle.done()