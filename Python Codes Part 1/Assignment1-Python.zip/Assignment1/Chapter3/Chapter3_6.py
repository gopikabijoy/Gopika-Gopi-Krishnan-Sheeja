'''
Program to find the character corresponding to an ASCII value

'''
A=eval(input("Enter an ASCII code: "))
print("The character is ", chr(A))