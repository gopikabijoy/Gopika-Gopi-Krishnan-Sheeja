'''
Program to print a rectangle using turtle

'''
import turtle

x,y=eval(input("Enter the center coordinates of the rectangle: "))
width,height=eval(input("Enter the width and height of the rectangle: "))


turtle.showturtle()
turtle.penup()
turtle.goto(x,y)
turtle.forward(width/2)
turtle.pendown()
turtle.left(90)
turtle.forward(height/2)
turtle.left(90)
turtle.forward(width)
turtle.left(90)
turtle.forward(height)
turtle.left(90)
turtle.forward(width)
turtle.left(90)
turtle.forward(height/2)

turtle.done()
 