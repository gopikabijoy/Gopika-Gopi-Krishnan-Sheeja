'''
Program to find the sum of digits of any number between 0 amd 1000

'''
N=eval(input("Enter a number between 0 and 1000: "))

q1=N//100  #to extract first digit
r1=N%100
q2=r1//10  #to extract second digit
r2=r1%10   #to extract third digit
Sum=q1+q2+r2

print("The Sum of the digits is ",Sum)