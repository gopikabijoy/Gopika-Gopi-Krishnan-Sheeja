'''
Program to calculate the BMI

'''

Wt=eval(input("enter the weight in Pound: "))*0.4535
Ht=eval(input("enter the height in inches: "))*0.0254
bmi=Wt/(Ht*Ht)
print("BMI is ",int(bmi*100)/100.0)