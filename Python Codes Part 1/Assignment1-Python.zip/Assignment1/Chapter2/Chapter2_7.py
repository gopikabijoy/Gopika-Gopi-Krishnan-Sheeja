'''
Program to find the number of Years and days from minutes

'''

Min=eval(input("Enter the number of minutes: "))

Years=Min//(365*24*60)       #to calculate the number of years
rem=Min%(365*24*60)
Days=rem//(60*24)            #to calculate the number of days

print(Min, " minutes is approximately" ,Years, "years and" ,Days, "days")