'''
Program to calculate the Total Savings amount after 6 months

'''

Saving=eval(input("Enter the monthly Saving Amount: "))

Rate=0.00417
M1=Saving*(1+Rate)
M2=(M1+Saving)*(1+Rate)
M3=(M2+Saving)*(1+Rate)
M4=(M3+Saving)*(1+Rate)
M5=(M4+Saving)*(1+Rate)
M6=(M5+Saving)*(1+Rate)

print("After the sixth month, the account value is ", int(M6*100)/100.0,"$")