'''
the program that prompts the user to enter the time zone in hours away from GMT and
displays the time in the specified time zone.

'''
import time

offset=eval(input("enter the time zone in hours away from (offset to) GMT: "))
            
currentTime = time.time() # Get current time

totalSeconds = int(currentTime)  # Obtain the total seconds since midnight, Jan 1, 1970
currentSecond = totalSeconds % 60
totalMinutes = totalSeconds // 60
currentMinute = totalMinutes % 60
totalHours = totalMinutes // 60
currentHour = totalHours % 24

offsettime=(currentHour+offset)%24

print("The time in Specified TimeZone is :",offsettime,":",currentMinute,":",currentSecond,"GMT")