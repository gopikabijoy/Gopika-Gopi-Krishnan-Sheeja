'''
program to find the Subtotal and Gratuity

'''

Subtotal,Gratuity=eval(input("Enter the subtotal and Gratuity Rate : "))
G=(Subtotal/100)*Gratuity
S=Subtotal+G 

print("The gratuity is",int(G*100)/100.0 ,"and the total is ",int(S*100)/100.0)