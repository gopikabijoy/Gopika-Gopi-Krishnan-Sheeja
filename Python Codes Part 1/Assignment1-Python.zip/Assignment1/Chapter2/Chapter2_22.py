'''
Program to find the population growth with user input for the number of Years

'''
P1=312032486
Y=eval(input("Enter the number of years: "))     #current population

B=(24*3600*365)/7   #Rate of birth per day
D=(24*3600*365)/13    #Rate of death per day
I=(24*3600*365)/45    #Rate of immigrant per day
R=(B-D+I)
P2=P1+(R*Y)

print("The population in",Y,"Years is",P2//1) #to display the population as an integer value