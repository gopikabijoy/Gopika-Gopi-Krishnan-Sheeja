'''
Program to print a series

'''
Sum=0
for i in range(1,98,2):
    Sum=Sum+((i)/(i+2))
print("Sum of the series :( 1 / 3 + 3 / 5 + 5 / 7 + 7 / 9 + 9 / 11 + 11 / 13 + ... + 95 / 97 + 97 / 99) is: ",round(Sum))        
