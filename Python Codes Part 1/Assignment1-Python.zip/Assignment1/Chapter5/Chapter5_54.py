'''
Write a program that draws a diagram for the function f(x) = x2
'''
import turtle 

turtle.forward(250)
turtle.penup()
turtle.goto(250,5)
turtle.write('X-axis')
turtle.goto(0,0)
turtle.pendown()
turtle.backward(250)
turtle.forward(250)


# y axis
turtle.left(90)
turtle.forward(250)
turtle.penup()
turtle.goto(5,250)
turtle.write('Y-axis')
turtle.goto(0,0)
turtle.pendown()
turtle.backward(250)
turtle.forward(250)



turtle.penup()
x=0
turtle.goto(x*50,x*x*50)
turtle.pendown()

# draw the graph
while x <= 14:
    x += 2
    turtle.goto(x*10,x*x)


turtle.penup()
x=0
turtle.goto(x*50,x*x*50)
turtle.pendown()

# draw the graph
while x <= 14:
    x += 2
    turtle.goto(-x*10,x*x)
    
turtle.hideturtle()
turtle.done()

