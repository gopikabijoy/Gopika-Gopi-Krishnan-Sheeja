'''
Program that computes future tuition

'''
tuition=10000
totalcost=0
n=1
for i in range(1,15):
    tuition+=(0.05*tuition)
    if i==10:
     print("The cost of tuition in 10 years is ",round(tuition))
    if i>10:
       totalcost+=tuition  
      
print("The total cost of 4 years tuition in 10 years from now is ",round(totalcost))