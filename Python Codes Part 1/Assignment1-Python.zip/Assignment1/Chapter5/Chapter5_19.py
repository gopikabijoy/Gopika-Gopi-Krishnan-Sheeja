'''
Program to display a pyramid

'''

num= eval(input("Enter an integer from 1 to 15: "))
space = " "
if num<=15:
    for i in range(1, num+1):
        for j in range(num, 1, -1):
            if (j<=i):
                print(j,end=' ')     
            else:
                print(' ',end=' ')
        for j in range(1, num+1):
            if (j<=i):
                print(j, end=" ")
        else:
            print(' ',end=' ')
        print()
else:
    print("Entered value should be less than 16")

    
        
    

     
        
    

        
