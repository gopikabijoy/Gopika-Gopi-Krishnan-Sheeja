'''
program that prompts the user
to enter the year and first day of the year, and displays the first day of each month
in the year on the console.

'''
year=eval(input("Enter the year : "))
day=eval(input("Enter the first day of the year.(0-monday,2-tuesady....6-sunday): "))
for i in range(1,12):
    if i==1: 
        rem=(day+31)%7
    elif (i==4 or i==6 or i==9 or i==11):
        rem=(rem+30)%7
        
    elif i==2:
        if (year%4==0 and year%100!=0)or(year%400==0):
             rem=(rem+29)%7
        else:
            rem=(rem+28)%7    
                
    elif (i==3 or i==5 or i==7 or i==8 or i==10):
        rem=(rem+31)%7
    
    
    if rem==0:
        name="Monday"
    elif rem==1:
        name="Tuesday"
    elif rem==2:
        name="Wednesday"
    elif rem==3:
        name="Thursday"
    elif rem==4:
        name="Friday"
    elif rem==5:
        name="Saturday"
    elif rem==6:
        name="Sunday"
        
    if i==1:
        print("February 1,",year,"is "+name)
    elif i==2:
        print("March 1,",year,"is "+name)
    elif i==3:
        print("April 1,",year,"is "+name)
    elif i==4:
        print("May 1,",year,"is "+name)
    elif i==5:
        print("June 1,",year,"is "+name)
    elif i==6:
        print("July 1,",year,"is "+name)
    elif i==7:
        print("August 1,",year,"is "+name)
    elif i==8:
        print("September 1,",year,"is "+name)
    elif i==9:
        print("October 1,",year,"is "+name)
    elif i==10:
        print("November 1,",year,"is "+name)
    elif i==11:
        print("December 1,",year,"is "+name)
    
        
    