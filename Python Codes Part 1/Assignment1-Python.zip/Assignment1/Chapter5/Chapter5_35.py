'''
Program to find the Perfect numbers less than 10000

'''
print("The perfect numbers are : ")
for i in range(2,10000):
    Sum=0
    for d in range(1,i):
        if i%d==0:
            Sum+=d
    
 
    if Sum==i:
        print(i)
