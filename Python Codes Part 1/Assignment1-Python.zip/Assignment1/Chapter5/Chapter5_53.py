'''
Write a program that plots the sine
function in red and cosine in blue

'''
import turtle 
import math

#x axis
turtle.forward(250)
turtle.penup()
turtle.goto(250,5)
turtle.write('X-axis')
turtle.goto(0,0)
turtle.pendown()
turtle.backward(250)
turtle.forward(250)


# y axis
turtle.left(90)
turtle.forward(250)
turtle.penup()
turtle.goto(5,250)
turtle.write('Y-axis')
turtle.goto(0,0)
turtle.pendown()
turtle.backward(250)
turtle.forward(250)

# to draw sine function
turtle.penup()
turtle.goto(-175,50)
turtle.pendown()
turtle.color("red")
x=0
for x in range(-175,176):
       turtle.goto(x,50*math.sin((x/100)*2*math.pi))
turtle.write("sine-graph")   
 
# to draw cosine function
turtle.penup()
turtle.goto(-175,0)
turtle.pendown()
turtle.color("blue")
x=0
for x in range(-175,176):
       turtle.goto(x,50*math.cos((x/100)*2*math.pi))
turtle.write("cos graph")

turtle.hideturtle()
turtle.done()