'''
program to display the winner for rock,paper,scissor game

'''


import random

user=0
computer=0
while (user!=3 and computer!=3):
    x = random.randint(0,2)
    
    y=eval(input("scissor (0), rock (1), paper (2): Please enter your Choice: "))
    if (x==0 and y==1):
        user+=1
        print("The computer is scissor.You are rock.You won")
    elif(x==0 and y==2):
        computer+=1
        print("The computer is scissor.You are paper.you lost")
    elif(x==1 and y==0):
        computer+=1
        print("The computer is rock.You are scissor.You lost")
    elif(x==1 and y==2):
        user+=1
        print("The computer is rock.You are paper.You won")
    elif(x==2 and y==0):
        user+=1
        print("The computer is paper.You are Scissor.You won")
    elif(x==2 and y==1):
        computer+=1
        print("The computer is paper.You are rock.you lost")
    else:
        print("Draw")
if user==3:
    print("You won!!")
elif computer==3:
    print("Computer Won!!")
