'''
Program to find the GCD of two numbers

'''
import math
n1,n2=eval(input("Enter the first and second number : "))
d=min(n1,n2)
while d>=1:
    if (n1%d==0)and(n2%d==0):
        break
    else:
        d=d-1
print("The Greatest Common divisor of ",n1," and ",n2,"is ",d)