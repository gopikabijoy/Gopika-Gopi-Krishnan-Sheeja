n = eval(input("How many Students do you have?"))
max,nextmax=0,0
for i in range(n): 
    x = eval(input("Enter score>>"))
    if x > max: 
        nextmax=max
        max = x 
print ("The highest score is", max)

print ("The second highest score is", nextmax)