'''
Program that returns the longest common prefix
of two strings

'''
def prefix(s1,s2):
    l1=len(s1)
    l2=len(s2)
    count=''
    for i in range(min(l1,l2)):
        if s1[i]==s2[i]:
            count+=s1[i]
        else:
            break
    if count!='':
        return count
    else:
        return 1
       
def main():
    string1=input("Enter the first string : ")
    string2=input("Enter the second string : ")
    result=prefix(string1,string2)
    if result!='':
        print("The longest common prefix of ",string1,"and ",string2,"is",result)
    else:
        print("There is no common prefix between the two strings")
    
main()
    