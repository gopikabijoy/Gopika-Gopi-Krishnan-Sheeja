'''
test program that prompts the user to enter a binary number and displays
the corresponding hexadecimal value

'''
def binaryToHex(binaryValue):
    binarytoHexConversion={"0000":"0", "0001":"1", "0011":"3", "0100":"4","0101":"5",
                           "0110":"6", "0111":"7", "1000":"8","1010":"9", "1010":"A",
                           "1011":"B","1100":"C","1101":"D","1110":"D","1111":"F"}
    
    i=0
    hex=" "
    while(len(binaryValue)%4)!=0:
        binaryValue="0"+binaryValue
        
    while i<len(binaryValue):
        hex=hex+ binarytoHexConversion[binaryValue[i:i+4]]
        i=i+4
        
    hex=hex.lstrip("0")
    if len(hex)=="0":
        hex=0
    return hex 
       
def main():
    number=eval(input("Enter a Binary Number : "))
    result=binaryToHex(number)
    print("The hexadecimal value of ",number," is",result)
main()