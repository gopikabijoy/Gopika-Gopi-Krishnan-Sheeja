'''
program that prompts the user to enter a password and displays valid
password if the rules are followed or invalid password otherwise

'''
def passwordcheck(p):
    
    l=len(p)
    count=0
    flag=0
    if (l>=8):                                    #first condition
        if p.isalnum():                           #alpha numeric condition                  
            for char in p:
                if char.isdigit():
                    count+=1
                    if count>=2:
                        return flag+1
        else:
            return flag
    else:
        return flag

def main():
    password=input("Enter a Password : ")
    result=passwordcheck(password)
    if result==1:
        print("Valid Password")
    else:
        print("Invalid Password")
        
main()
    