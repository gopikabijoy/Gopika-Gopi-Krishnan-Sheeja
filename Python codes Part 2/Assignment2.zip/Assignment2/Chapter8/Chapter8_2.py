'''
program that prompts the user to enter two strings and then checks
whether the first string is a substring of the second string.

'''
def main():
    
    s1=input("Enter the first string ")
    s2=input("Enter the second string ")
    result=s2.find(s1)
    if result!=-1:
        print(s1," is a substring of ",s2)
    else:
        print(s1,"is not a substring of",s2)
        
main()