'''
program that prompts the user to enter two points, displays the distance between
them, and indicates whether they are near each other

'''
from math import sqrt 
class Point:
    def __init__(self,X=0,Y=0):
        self.__x=X
        self.__y=Y
        
    def getx(self):
        return self.__x
    
    def gety(self):
        return self.__y
    
    def distance(self,p):
        d=sqrt((self.__x-p.getx())**2 +(self.__y-p.gety())**2)
        return d
    
    def isNearBy(self,p1):
        x=p1.getx()
        y=p1.gety()
        flag='true'
        if self.distance(p1)<5:
            return flag
        else:
            flag='false'
            return flag 
        
        def __str__(self):
            x=str(self.__x)
            y=str(self.__y)
            return'(' + x + ',' + y + ')'
            
        
         
def main():
    
    x1,y1,x2,y2=eval(input("Enter two points x1, y1, x2, y2: "))
    point1=Point(x1,y1)
    point2=Point(x2,y2)
    result1=point1.distance(point2)
    result2=point1.isNearBy(point2)
    print("The distance between the two points is ",int(result1*100.0)/100)
    if result2=='true':
        print("The two points are near to each other")
    else:
        print("The two points are not near to each other")
main()
