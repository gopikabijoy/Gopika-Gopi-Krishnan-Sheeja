'''
test program that prompts the user to enter a string and displays the number
of letters in the string.

'''
def countLetters(s):
    flag=0
    l=len(s)
    for i in range (0,l):
        flag+=1
    return flag
    
    
def main():
    string=input("Enter a string : ")
    result=countLetters(string)
    print(result)
main()