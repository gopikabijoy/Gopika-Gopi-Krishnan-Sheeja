'''
sort function that uses the bubble-sort algorithm

'''
def main():
    list1 = list(eval(input("Enter the list to be sorted :")))
    bubbleSort(list1)
    
    
def bubbleSort(lst):
    for j in range(len(lst)):
        for i in range(len(lst) - 1):
            if(lst[i] > lst[i + 1]):
                lst[i], lst[i + 1] = lst[i + 1], lst[i]
        
    print(lst)
    
main()