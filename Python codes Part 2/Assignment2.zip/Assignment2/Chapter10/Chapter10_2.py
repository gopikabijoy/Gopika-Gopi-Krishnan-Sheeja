'''
program that reads a list of integers and
displays them in the reverse order in which they were read

'''
def main():
    list1 = []
    
    lengthOfList = eval(input("enter the length of the list :"))
    
    for i in range(lengthOfList):
        values = eval(input("enter the " +str(i) +" index number :"))
        list1.append(values)
        
    list2 = []  
      
    for j in range(1,len(list1)+1):
        list2.append(list1[len(list1) - (len(list1) + j)])
        
    print("Original list entered :",list1)
    print("the reverse list is :",list2)
    
main()