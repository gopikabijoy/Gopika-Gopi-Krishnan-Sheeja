'''
program that reads some integers
between 1 and 100 and counts the occurrences of each

'''
def count(lists):
    d=[]
    for value in lists:
        if value not in d:
            d.append(value)
            print(d)
    l=len(lists)
    for i in range(len(d)):
        flag=0
        for j in range(i,l):
            if (lists[j]==d[i]):
                flag+=1
        print(lists[i],"occurs ",flag," times")
    
def main():
    l=input("Enter integers between 1 and 100  : ")
    item=l.split(' ')
    lists=[eval(x) for x in item]
   
    count(lists)
    
        
main()