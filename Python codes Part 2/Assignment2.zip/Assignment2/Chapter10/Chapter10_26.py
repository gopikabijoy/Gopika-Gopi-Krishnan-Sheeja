'''
program that prompts the user to enter two sorted lists and
displays the merged list

'''
def merge(list1,list2):
    l1=len(list1)
    l2=len(list2)
    l=[]
    for x in list1:
        l.append(x)
    
    for y in list2:
            l.append(y)
            
    L=l1+l2
    
            
    for i in range(L):
        for j in range(L-1):
            if(l[j]>l[j+1]):
                l[j],l[j+1]=l[j+1],l[j]
    return l
      
def main():
    list=input("Enter list 1 :")
    items=list.split(" ")
    list1=[eval(x) for x in items]
    
    lists=input("Enter list 2 :")
    items=lists.split(" ")
    list2=[eval(x) for x in items]
    
    result=merge(list1,list2)
    print("The merged list is : ")
    print(result)
   
main()  