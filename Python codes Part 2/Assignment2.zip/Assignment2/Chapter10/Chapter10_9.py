'''
program that prompts the user to enter a list of numbers and displays
the mean and standard deviation

'''
from math import sqrt 
def mean(lists):
    
    l=len(lists)
    s=0
    for i in range(l):
        s+=lists[i]
    M=s/l  
    return M
    
def deviation(lists):  
    l=len(lists)
    sum=0
    
    for i in range(l):
        sum+=(lists[i]-mean(lists))**2
    SD=sqrt(sum/(l-1))
    return SD
    
def main():
    list=input("Enter Numbers: ")
    item=list.split(" ")
    lists=[eval(x) for x in item]
    
    list1=mean(lists)
    list2=deviation(lists)
    print("The Mean is : ",int(list1*100.0)/100)
    print("The Standard Deviation is : ",int(list2*100.0)/100 )
    
main()