'''
program that prompts the user to enter a list and displays whether the
list is sorted or not(ascending order)

'''
