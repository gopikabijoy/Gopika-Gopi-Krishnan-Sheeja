'''
program that prompts the user to enter a two dimensional
list and displays the location of the largest element in the list

'''

def locateLargest(a):
    flag=a[0][0]
    r=len(a)
    c=len(a[1])
    row=0
    column=0
    L=[]
    for i in range(r):
        for j in range(c):
            if a[i][j]>flag:
                flag=a[i][j]
                row=i
                column=j
    L.append(row)
    L.append(column)
    return(L)
            
                
def main():
    
    r=eval(input("Enter the number of rows : "))
    matrix=[]
    for row in range(r):
        s="Enter a "+str(r)+" by "+str(r)+" matrix row for row "+str(row+1)+" : "
        a=input(s).strip().split()
        matrix.append([eval(x)for x in a])
        
    result=locateLargest(matrix)
    print("The location of the largest element is at ","(",result[0] ,"," ,result[1],")")

main()