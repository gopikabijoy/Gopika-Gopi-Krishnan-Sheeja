'''
program that prompts the user to enter a 3*3 matrix of numbers and
tests whether it is a Markov matrix

'''
def isMarkovMatrix(m):
    flag=0
    sum=0
    for i in range(3):
        for j in range(3):
            if (m[i][j]>0) :
                sum+=m[j][i]
                flag+=1
    if flag==9:
        return 0
    else:
        return 1
def creatematrix(r,c):
    matrix=[]
    for row in range(r):
        
        s="Enter a "+str(r)+" by "+str(r)+" matrix row for row "+str(row+1)+" : "
        a=input(s).strip().split()
        matrix.append([eval(x)for x in a])
    return (matrix)


r=creatematrix(3,3) 
                
result=isMarkovMatrix(r)
if result==0:
    print("It is a Markov matrix ")
else:
    print("It is not a Markov matrix ")