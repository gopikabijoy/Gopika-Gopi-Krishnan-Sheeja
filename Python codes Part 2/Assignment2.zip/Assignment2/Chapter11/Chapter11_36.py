'''
Turtle program that displays a random path that starts from the center and ends at
a point on the boundary

'''
import random
import turtle

def move(pos,dx=0,dy=0):
    return(pos[0]+dx,pos[1]+dy)



turtle.setworldcoordinates(-8,-8,8,8)
current_pos=[0,0]
visited_points=[current_pos]
possible_moves=[move(current_pos,dx=dx) for dx in range(-1,2) if -8<=current_pos[0]+dx<=8]+\
    [move(current_pos,dy=dy) for dy in range(-1,2) if -8<=current_pos[1]+dy<=8]
available_moves=[m for m in possible_moves if m not in visited_points]
while len(available_moves)!=0 and 8 not in current_pos and -8 not in current_pos:
    current_pos=random.choice(available_moves)
    visited_points.append(current_pos)
    turtle.goto(current_pos[0],current_pos[1])
        
    possible_moves=[move(current_pos,dx=dx) for dx in range(-1,2) if -8<=current_pos[0]+dx<=8]+\
        [move(current_pos,dy=dy) for dy in range(-1,2) if -8<=current_pos[1]+dy<=8]
    available_moves=[m for m in possible_moves if m not in visited_points]

turtle.hideturtle()
turtle.done()