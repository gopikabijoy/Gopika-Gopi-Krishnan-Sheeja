'''
function to add two matrices

'''
from math import sqrt

#Add 2 matrices

def addMatrix(a,b):
    c=[]
    for i in range(3):
        c.append([])
        for j in range(3):
            c[i].append(a[i][j]+b[i][j])
    return c

#Generate a matrix

def getMatrix(num = ''):
    matrix = []
    string = 'Enter Matrix ' + str(num)+" (order 3*3)" + ':'
    line =input(string).split()
    n = round(sqrt(len(line)))
    for i in range(len(line)):
        if i % n == 0:
            matrix.append([])
        matrix[i // n].append(eval(line[i]))
    return matrix
                    

   
matrix1=getMatrix(1)
matrix2=getMatrix(2)
matrix3=addMatrix(matrix1,matrix2)
print('\n Matrices are added as below:')
for i in range(3):
    print(('{0:5.1f}{1:5.1f}{2:5.1f}{3:>3s}{4:5.1f}{5:5.1f}{6:5.1f}{7:>3s}' + '{8:5.1f}{9:5.1f}{10:5.1f}')
            .format(matrix1[i][0], matrix1[i][1], matrix1[i][2],
            ' ' if i!= 1 else '+', matrix2[i][0], matrix2[i][1], matrix2[i][2], 
            ' ' if i!= 1 else '=', matrix3[i][0], matrix3[i][1], matrix3[i][2]))
              
