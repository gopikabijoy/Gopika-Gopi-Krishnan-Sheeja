'''
program that prompts the user to enter the students 
names and their scores on one line, and prints student names in increasing order of their scores.

'''
matrix=input("Enter students names and scores ").split()
scores_names=[[eval(matrix[i+1]),matrix[i]] for i in range (0,len(matrix),2)]
scores_names.sort()

for [score,name] in scores_names:
    print('{0:<8s}{1:<d}'.format(name,score))
    