'''
program that randomly fills in 0s and 1s into
a 4*4 matrix, prints the matrix, and finds the rows and columns with the most
1s.
'''
import random

def index1(m):
    L=[]
    count=0
    for i in range(4):
        for j in range(4):
            if m[i][j]==1:
                count+=1
        L.append(count)
        count=0
    return(L)

def index2(m):
    L=[]
    count=0
    for i in range(4):
        for j in range(4):
            if m[j][i]==1:
                count+=1
        L.append(count)
        count=0
    return(L)
    
def main():
    matrix=[]
   
    for row in range(4):
        matrix.append([])
        for column in range(4):
            value =random.randint(0,1)
            matrix[row].append(value)
        
        
    for row in range(len(matrix)):
        for column in range(len(matrix[row])):
            print(matrix[row][column], end = " ")
        print()
    print()   
    
    r= index1(matrix)
    h=max(r)
    row=r.index(h)
    
    R= index2(matrix)
    H=max(R)
    ROW=R.index(H)

        
    print("The largest row index is : ",row)
    print("The largest column index is : ",ROW)
main()