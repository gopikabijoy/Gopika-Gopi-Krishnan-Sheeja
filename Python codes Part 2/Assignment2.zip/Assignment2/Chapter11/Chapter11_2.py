'''
a test program that reads a matrix and
displays the sum of all its elements on the major diagonal

'''
def sumMajorDiagonal(m):
    sum=0
    for i in range(len(m)):
        for j in range(len(m[i])):
            if i==j:

                sum += m[i][i]
    return(sum)


def creatematrix(r,c):
    matrix=[]
    for row in range(r):
        
        s="Enter a "+str(r)+" by "+str(r)+" matrix row for row "+str(row+1)+" : "
        a=input(s).strip().split()
     
        matrix.append([eval(x)for x in a])

    
    print("Sum of the elements in the major diagonal is ",sumMajorDiagonal(matrix))
    
def main():
    creatematrix(4,4)
    
main()
    
            
               