'''
Design a class named Triangle that extends the
GeometricObject class.

'''
from math import sqrt
from GeometricObjects import GeometricObjects

class Triangle(GeometricObjects):
    def __init__(self,side1=1.0,side2=1.0,side3=1.0,color='red',filled=1):
        super().__init__(color,filled)
        self.side1=side1
        self.side2=side2
        self.side3=side3
    def getside1(self):
            return self.side1
    def getside2(self):
            return self.side2
    def getside3(self):
            return self.side3
    def setside1(self,side1):
        self.side1=side1
    def setside2(self,side2):
        self.side2=side2
    def setside3(self,side3):
        self.side3=side3
        
    def getArea(self):
            s=self.side1+self.side2+self.side3
            area=sqrt(s*(s-self.side1)*(s-self.side2)*(s-self.side3))
            return area
    def getPerimeter(self):
            perimeter=self.side1+self.side2+self.side3
            return perimeter
    def __str__():
            return ("Triangle: side1 = " + str(side1) + " side2 = " +
            str(side2) + " side3 = " + str(side3))

def main():
    s1,s2,s3=eval(input("Enter the three sides of the triangle :"))
    c=input("Enter the color ")
    f=bool(input("Enter an option: 1(filled) or 0(not filled) "))
    T=Triangle(s1,s2,s3,c,f)
    print("The area of the triangle is : ",T.getArea())
    print("The Perimeter of the triangle is : ",T.getPerimeter())
    print("The Color of the triangle is : ",T.getColor())
    print("Filled ? : ",T.isFilled())
    
main()
    
    