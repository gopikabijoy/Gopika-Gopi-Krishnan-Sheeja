class Account:
    def __init__(self,id=0,initialbalance=100,AnnualInterestRate=0):
        self.__balance=initialbalance
        self.__id=id
        self.__annualInterestRate=AnnualInterestRate

    def balance(self):
        return self.__balance
    
    def id(self):
       return self.__id
    
    def annualInterestRate(self):
        return self.__annualInterestRate
    
    def getMonthlyInterestRate(self):
        return self.__annualInterestRate/12
    
    def getMonthlyInterest(self):
        return (self.__balance*(self.getMonthlyInterestRate())/100)
    def setid(self,id):
        self.__id=id
    def setbalance(self,balance):
        self.__balance=balance
    def setAnnualInterestRate(self,rate):  
        self.__annualInterestRate=rate 
         
    def withdraw(self,amt):
        
       self.__balance-=amt
       return self.__balance

    def deposit(self,amt):
   
        self.__balance+=amt
        return self.__balance
