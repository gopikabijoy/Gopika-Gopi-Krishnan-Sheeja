'''
Design a class named Location for locating a maximal
value and its location in a two-dimensional list

'''


class Location:
    def __init__(self,row,column,maxValue):
        self.row=row
        self.column=column
        self.maxValue=maxValue
        
    def getvalues(self):
        return self.row,self.column

    
    def getmaxValue(self):
        return self.maxValue
    
    def setrow(self,row):
        self.row=row
        
    def setcolumn(self,column):
        self.column=column
        
    def setmaxValue(self,maxValue):
        self.maxValue=maxValue
        
    def setvalues(self,row,column):
            self.setrow(row)
            self.setcolumn(column)
        

def locateLargest(a):
    max=Location(0,0,a[0][0])
    for i in range(len(a)):
        for j in range(len(a[i])):
            if (a[i][j]>max.getmaxValue()):
                max.setvalues(i,j)
                max.setmaxValue(a[i][j])
    return max
    
matrix=[]
r,c=eval(input("Enter the number of rows and columns in the list : "))
for i in range(r):
    matrix.append([eval(x) for x in input('Enter row'+str(i)+':').split()])
    while len(matrix[i])!=c:
        print('There should be ',c,'entries in row ',i)
        matrix[i]=[eval(x) for x in input('Enter row' + str(i) +':').split()]
        
max=locateLargest(matrix)
print("The largest element is {0} and is located at {1}".format(max.getmaxValue(),max.getvalues()))
   

