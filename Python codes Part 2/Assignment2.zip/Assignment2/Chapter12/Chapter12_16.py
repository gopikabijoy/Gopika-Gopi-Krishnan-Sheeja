'''
Define a new Stack class using inheritance
that extends list

'''
class Stack(list):
    
    def isEmpty(self):
        return (len(self) == 0)
    
    def peek(self):
        if self.isEmpty():
            return None
        else:
            return self[len(self) -1]
        
    def push(self, value):
        self.append(value)
    
    def pop(self):
        if self.isEmpty():
            return None
        else:
            return super().pop()
        
    def getSize(self):
        return len(self)
    
def main():
    
    UserInput = [Stack(input("Enter the string " +str(i+1)+":")) for i in range(5)]
        
    print("the elements in the stack :")
    for a in range(5):
        for b in range(len(UserInput[a])):
            print(UserInput[a].pop(), end ="")
        print()    
    
    
main()
    
    
    
            