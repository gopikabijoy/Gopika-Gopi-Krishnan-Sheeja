'''
Account class created in to simulate
an ATM machine

'''
from Account import Account             # extending Account class from chapter7_3 module

def createaccounts():
    acct=[]
    for i in range(10):
        acct.append(Account(id=i))
    return acct

class Menu:
    def __init__(self,account):
        self.account=account
        ch=0
        while (ch!=4):
            self.display()
            ch=self.getchoice()
            if ch in [1,2,3]:
                [self.choice1,self.choice2,self.choice3][ch-1]()
                
    def display(self):
        print("Main Menu")
        print("1.Check balance")
        print("2.Withdraw")
        print("3.Deposit")
        print("4:Exit")
    
    def getchoice(self):
        ch=eval(input("Enter a choice : "))
        while ch not in [1,2,3,4]:
            print("Invalid Choice")
            ch=eval(input("Enter a choice : "))
        return ch
    
    def choice1(self):
        print("The balance is : ",self.account.balance())
        
    def choice2(self):
        amt=eval(input("Enter an amount for withdrawal : "))
        self.account.withdraw(amt)
                 
    def choice3(self):
        amt=eval(input("Enter an amount to deposit : "))
        self.account.deposit(amt)
        
def main():
    C=createaccounts()
    ids=[x.id() for x in C]
    
    while True:
        id=eval(input("Enter an account id : "))
        while id not in ids:
            print("Invalid Choice.Try Again")
            id=eval(input("Enter an account id : "))
            
        menu=Menu(C[id])    
        
main()
    
    
    
    
    

    