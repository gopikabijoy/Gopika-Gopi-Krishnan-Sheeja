'''
test program that prompts the
user to enter two integers and displays their GCD.

'''
def gcd(m, n):
    if m % n==0:
        GCD=n
    else:
        GCD=gcd(n,m % n)
    return GCD
        
def main():
    number1,number2=eval(input("Enter 2 integers : "))
    result=gcd(number1,number2)
    print("The Greatest Common Divisor of ",number1,"and ",number2,"is",result)
        
main()