'''
recursive function that computes
the sum of the digits in an integer

'''
def sumDigits(n):
    if n<10:
        return n
    else:
        return sumDigits(n//10)+(n%10)
    
def main():
    number=eval(input("Enter a number : "))
    result=sumDigits(number)
    print("The sum of the digits of",number,"is",result)
    
main()
   