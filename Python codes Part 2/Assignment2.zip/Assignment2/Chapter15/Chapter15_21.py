'''
recursive function that parses a binary number as a
string into a decimal integer.

'''
def binaryToDecimal(binaryString):
    
    if (len(binaryString)==1):
        return int(binaryString)
    return 2*binaryToDecimal(binaryString[:-1])+int(binaryString[-1]) 

number=input("Enter a binary number : ")
print("The decimal equivalent of "+number+" is",binaryToDecimal(number))
    
    
