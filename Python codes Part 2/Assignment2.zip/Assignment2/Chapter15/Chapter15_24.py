'''
program that prompts the user to enter a
directory and displays the number of files in the directory.

'''
import os

def getNumFiles(path):
    lst=os.listdir(path)
    for subdirectory in lst:
        numFiles+=getNumFiles(path+'\\'+subdirectory)
    else:
        numFiles+=1
    return  numFiles

def main():
    path=input("Enter a directory :").strip()
    try:
        print("There are",getNumFiles(path),'files in',path)
    except:
        print("Directory doesnot exist")
        
main()