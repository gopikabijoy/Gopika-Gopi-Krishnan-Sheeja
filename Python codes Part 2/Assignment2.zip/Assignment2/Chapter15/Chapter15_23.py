'''
recursive function to print all the permutations of a
string.

'''
def displayPermutation(s):
    displayPermutationHelper("",s)
    
def displayPermutationHelper(s1, s2):
    if s2=="":
        print(s1)
    else:
        l=len(s2)
        for i in range(0,l):
            displayPermutationHelper(s1+s2[i],s2[:i]+s2[i+1:])
    
string=input("Enter a String : ")
print("The permutations are:")
displayPermutation(string)

    
    
    
    
    
    
    

    