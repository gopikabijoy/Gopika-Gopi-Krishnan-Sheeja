'''
program that will count the
number of characters, words, and lines in a file

'''
def main():
    while True:
    
        try:
        
            fname=input("Enter a filename : ").strip()
            f1=open(fname,"r")
            break
        except IOError:
            print(fname,"donot exist")
        
    char=0
    word=0
    lines=0
    for line in f1:
        char+=len(line)
        w=line.split()
        word+=len(w)
        lines+=1
        
    print(char," Characters")
    print(word," Words")
    print(lines," Lines")
    
    f1.close()
main()
        
