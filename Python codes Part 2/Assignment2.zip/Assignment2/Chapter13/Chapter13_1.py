'''
program that removes all the occurrences of a specified
string from a text file

'''
filename=input("Enter a filename: ")
s=input("Enter the string to be removed: ")

ifile=open(filename,'r')
f1=ifile.read()
ifile.close()

f1=f1.replace(s,' ')

ofile=open(filename,'w')
ofile.write(f1)
ofile.close()

print(str(s)+'is removed from the file')