'''
program that reads the scores from the file and displays their
total and average

'''
def main():
    while True:
    
        try:
        
            fname=input("Enter a filename : ").strip()
            f1=open(fname,"r")
            break
        except IOError:
            print(fname,"donot exist")
    
    score=[eval(x) for x in f1.read().split()]
    
    f1.close()
    print("There are ",len(score)," scores")
    print("The Total is : ",sum(score))
    print("The Average is : ",(sum(score)/len(score)))
          
main()
    