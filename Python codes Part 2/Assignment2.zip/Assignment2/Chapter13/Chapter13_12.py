'''
Define an exception class named TriangleError
that extends RuntimeError. The TriangleError class contains the private
data fields side1, side2, and side3 with accessor methods for the three
sides of a triangle. Modify the Triangle class in Exercise 12.1 to throw a
TriangleError exception if the three given sides cannot form a triangle
'''

from math import sqrt

class GeometricObject:
    def __init__(self, color = "green", filled = True):
       self.__color = color
       self.__filled = filled

    def getColor(self):
        return self.__color

    def setColor(self, color):
        self.__color = color

    def isFilled(self):
        return self.__filled

class Triangle (GeometricObject):
    def __init__(self, side1 = 1.0, side2 = 1.0, side3 = 1.0, color = "green", filled = True):
        super().__init__(color, filled)
        self.__side1 = side1
        self.__side2 = side2
        self.__side3 = side3

    def getSide1(self):
        return self.__side1

    def getSide2(self):
        return self.__side2

    def getSide3(self):
        return self.__side3

    def getPerimeter(self):
        return self.__side1+ self.__side2+ self.__side3

    def getArea(self):
        s = (self.__side1 + self.__side2+ self.__side3) / 2
        return sqrt(s* (s-self.__side1) * (s-self.__side2) * (s-self.__side3))

    def setSide1(self, side1):
        self.__side1 = side1

    def setSide2(self, side2):
        self.__side1 = side2

    def setSide3(self, side3):
        self.__side1 = side3

    def __str__(self):
        return " Triangle: side1 = "+ self.getSide1() + " side2 = "+ self.getSide2() +" side3 = "+ self.getSide3()

    def isValid(self):
        if(self.__side1==0 or self.__side2 ==0 or self.__side3 ==0):
            raise TriangleError(self.__side1,self.__side2, self.__side3)

        if((self.__side1 + self.__side2) < self.__side3
        or (self.__side2 + self.__side3) < self.__side1
        or (self.__side1 + self.__side3) < self.__side2):
            raise TriangleError(self.__side1, self.__side2, self.__side3)


class TriangleError(RuntimeError):
    def __init__(self, side1, side2, side3):
        self.__side1 = side1
        self.__side2 = side2
        self.__side3 = side3

        super().__init__(str(self.__side1)+ ', '+
                         str(self.__side2)+' , '+ str(self.__side3)+ ' cannot form a triangle')



def main():
    side1, side2, side3 = eval(input(" Enter three sides: "))

    color = input(" Enter a color:  ")
    filled = bool(input(" Enter 1 for filled and 0 for  unfilled:" ))

    triangle = Triangle(side1,side2,side3, color,filled)

    triangle.isValid()
    print("\n Area ", triangle.getArea())
    print("\n Perimeter ", triangle.getPerimeter())
    print("\n Color ", triangle.getColor())
    print("\n Filled ", triangle.isFilled())

main()