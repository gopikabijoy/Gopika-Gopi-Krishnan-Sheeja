'''
program that prompts the user to enter a
text filename and displays the number of vowels and consonants in the file

'''
import os
import sys

def main():
    
    set1 = {"A","E","I","O","U","a","e","i","o","u"}
    
    fileName = input("Enter a Python source code filename: ").strip()
    
    if not os.path.isfile(fileName): 
        print("File", fileName, "does not exist")
        sys.exit()
        
    infile = open(fileName, "r")
    
    text = infile.read()
    infile.close()
    
    count = 0
    vowelsCount = 0
    
    for charc in text:
        if charc.isalpha():
            if charc in set1:
                vowelsCount += 1
    
    print("number of vowels found:", vowelsCount) 
    
main()