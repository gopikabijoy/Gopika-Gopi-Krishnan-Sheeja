'''
Program using a dictionary to store the pairs
of states and capitals so that the questions are randomly displayed
'''
def main():
    
    state_capital ={
        'Alabama': 'Montgomery','Alaska': 'Juneau','Arizona':'Phoenix','Arkansas':'Little Rock','California': 'Sacramento','Colorado':'Denver',
        'Connecticut':'Hartford','Delaware':'Dover','Florida': 'Tallahassee','Georgia': 'Atlanta','Hawaii': 'Honolulu','Idaho': 'Boise',
        'Illinios': 'Springfield','Indiana': 'Indianapolis','Iowa': 'Des Monies','Kansas': 'Topeka','Kentucky': 'Frankfort','Louisiana': 'Baton Rouge',
        'Maine': 'Augusta','Maryland': 'Annapolis','Massachusetts': 'Boston','Michigan': 'Lansing','Minnesota': 'St. Paul','Mississippi': 'Jackson',
        'Missouri': 'Jefferson City','Montana': 'Helena','Nebraska': 'Lincoln','Neveda': 'Carson City','New Hampshire': 'Concord','New Jersey': 'Trenton',
        'New Mexico': 'Santa Fe','New York': 'Albany','North Carolina': 'Raleigh','North Dakota': 'Bismarck','Ohio': 'Columbus','Oklahoma': 'Oklahoma City',
        'Oregon': 'Salem','Pennsylvania': 'Harrisburg','Rhoda Island': 'Providence','South Carolina': 'Columbia','South Dakoda': 'Pierre','Tennessee': 'Nashville',
        'Texas': 'Austin','Utah': 'Salt Lake City','Vermont': 'Montpelier','Virginia': 'Richmond','Washington': 'Olympia','West Virginia': 'Charleston',
        'Wisconsin': 'Madison','Wyoming': 'Cheyenne'  
    }
    
    correctAnswer = 0
    incorrectAnswer = 0
    
    for state in state_capital:
        capital = state_capital[state]
        userEntry = input("enter the captial of "+state+"?")
        if(userEntry.upper() == capital.upper()):
            correctAnswer += 1
            print("Correct Answer")
        else:
            print("Incorrect Answer")
            incorrectAnswer += 1
    
    print("The correct count is ",correctAnswer)
    
main()