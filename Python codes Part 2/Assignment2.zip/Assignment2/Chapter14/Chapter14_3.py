'''
program that reads in a Python
source code file and counts the occurrence of each keyword in the file.

'''
import os.path
import sys

def main():
    
    keyWords = {"and", "as", "assert", "break", "class", "continue", "def", "del", "elif", "else","except", "False", 
                "finally", "for", "from", "global", "if", "import", "in", "is", "lambda", "None", "nonlocal", "not", 
                "or", "pass", "raise", "return", "True", "try", "while", "with", "yield"}
    
    fileName = input("Enter a Python source code filename: ").strip()
    
    if not os.path.isfile(fileName): 
        print("File", fileName, "does not exist")
        sys.exit()
        
    infile = open(fileName, "r")
    
    text = infile.read().split()
    
    count = 0
    foundKeywords = {}
    
    for word in text:
        if word in keyWords:
            count += 1
            if word in foundKeywords:
                foundKeywords[word] += 1
            else:
                foundKeywords[word] =1    
            
    print("Total keywords in", fileName, "are", count)
    
    for keyword in foundKeywords:
        print(keyword, "===",foundKeywords[keyword])

main()